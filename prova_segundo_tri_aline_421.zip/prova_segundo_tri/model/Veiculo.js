module.exports = class Veiculo { 
  constructor() {
	this.placa = "";
  this.modelo = "";
	this.fabricante = 0;
	this.ano = 0;
  }
  
  setPlaca(p) {
	this.placa = p;
  }
  
  getPlaca() {
	return this.placa;  
  }
  
  setModelo(m) {
	this.modelo = m;
  }
  
  getModelo() {
	return this.modelo;  
  }
  
  setFabricante(f) {
  this.fabricante = f;
  }
  
  getFabricante() {
    return this.fabricante;  
  }
  
  setAno(a) {
	this.ano = a;
  }
  
  getAno() {
	return this.ano;  
  }
  
  inserir(connection) {
	try {
		var sql = "INSERT INTO veiculos (placa,modelo,fabricante,ano) VALUES(?, ?, ?, ?)";

		connection.query(sql, [this.placa, this.modelo, this.fabricante, this.ano], function (err, result) {
		  if (err) throw "teste";
		  //if (err) console.error('err from callback: ' + err.stack);
		  });
	} catch (e) {
		console.error('err from callback: ' + e.stack);
		throw e;
	}
  }
  
  listar(connection, callback) {
    var sql = "SELECT * FROM veiculos";

    connection.query(sql, function (err, result) {
		if (err) throw err;
		return callback(result);
    });    
  }
  
  pesquisar(connection, callback) {
    var sql = "SELECT * FROM veiculos WHERE modelo like ?";

    connection.query(sql, [this.modelo], function (err, result) {
		if (err) throw err;
		return callback(result);
    });    
  }
  
}