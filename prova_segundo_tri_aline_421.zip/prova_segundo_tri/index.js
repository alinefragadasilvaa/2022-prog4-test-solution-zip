const express = require('express');
const app = express();    

app.use(express.static(__dirname + '/views'));

app.listen(3000, function(){
  console.log("Servidor no ar - Porta: 3000!")
});

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended:true}));

const Veiculo = require('./model/Veiculo');

var mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "prova",
  password: "12345678",
  database: "detran"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Banco de dados conectado!");
});


// NAVEGAÇÃO

app.get('/', function(req, res){
	res.sendFile(__dirname + '/views/index.html');
});

app.get('/veiculos', function(req, res){
	var v = new Veiculo();  
    v.listar(con, function(result){
		res.render('lista.ejs', {veiculos: result});
	});
});

app.get('/cadastrarVeiculo', function(req, res){
	res.sendFile(__dirname + '/views/form.html');
});

// FUNÇÕES CADASTRAR E CONSULTA

app.post('/filtrarVeiculo', function(req, res){
	var v = new Veiculo();
	v.setModelo(req.body.modelo);
	
	if (v.getModelo() == '') {
		v.setModelo('%');
	}
	
	v.pesquisar(con, function(result){
		res.render('lista.ejs', {veiculos: result});
	});
});


app.post('/salvarVeiculo', function(req, res){
	try {
		var v = new Veiculo();
		
		v.setPlaca(req.body.placa);
		v.setModelo(req.body.modelo);
		v.setFabricante(req.body.fabricante);
		v.setAno(req.body.ano);
		
		var retorno = v.inserir(con);
		console.log('Aqui: ' + retorno);
	} catch (e) {
		console.log('Erro: '+e.message);
	}
	res.render('resultado.ejs', {param: v});
});