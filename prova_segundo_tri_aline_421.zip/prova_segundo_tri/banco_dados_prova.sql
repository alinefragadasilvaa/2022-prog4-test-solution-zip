create database detran;
use detran;
create table veiculos (
   placa varchar(8) not null,
   modelo varchar(100),
   fabricante int,
   ano int,
   primary key(placa)
);

CREATE USER 'prova'@'localhost' IDENTIFIED BY '12345678';

GRANT ALL PRIVILEGES ON *.* TO
'prova'@'localhost';

FLUSH PRIVILEGES;

select * from veiculos;